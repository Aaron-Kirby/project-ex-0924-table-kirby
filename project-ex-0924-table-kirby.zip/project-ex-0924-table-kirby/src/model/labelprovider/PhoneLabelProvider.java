package model.labelprovider;


import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.swt.widgets.Text;

import model.Person;

public class PhoneLabelProvider extends ColumnLabelProvider{
 
@Override
public String getText(Object element) {
      Person p = (Person) element;
      return p.getPhone();
   }
}
