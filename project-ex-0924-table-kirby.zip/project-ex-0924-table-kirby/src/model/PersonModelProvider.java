package model;

import java.util.*;

import util.UtilFile;

public enum PersonModelProvider {
	// INSTANCE;
	INSTANCE(getFilePath()); // Call a constructor with a parameter. 

	private List<Person> persons;

        // Load the data sets from a file dynamically. 
	private PersonModelProvider(String inputdata) {
		List<String> contents = UtilFile.readFile("C:\\Users\\KirbyPC\\workspace_CSCI8710_Kirby\\project-ex-0924-table-kirby\\input_init.csv");
		List<List<String>> tableContents = UtilFile.convertTableContents(contents);

		persons = new ArrayList<Person>();                     
			persons.add(new Person("Emma", "Smith", "402-111-1111", "emmasmith@email.com"));
		      persons.add(new Person("Olivia", "Johnson", "402-111-2222", "oliviajohnson@email.com"));
		      persons.add(new Person("Liam", "Williams", "402-111-3333", "liamwilliams@email.com"));
	}

	private static String getFilePath() {
		return "C:\\Users\\KirbyPC\\workspace_CSCI8710_Kirby\\project-ex-0924-table-kirby\\input_init.csv";
	}

	public List<Person> getPersons() {
		return persons;
	}
}