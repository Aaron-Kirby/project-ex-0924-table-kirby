
package handler;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.e4.ui.workbench.modeling.EPartService;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.e4.ui.model.application.ui.basic.MPart;

import model.Person;
import model.PersonModelProvider;
import util.MsgUtil;
import view.MyTableViewer;
import util.UtilFile;

public class AddPersonHandler {
   @Inject
   private EPartService epartService;
   @Inject
   @Named(IServiceConstants.ACTIVE_SHELL)
   Shell shell;

   private List<Person> persons;
   @Execute
   public void execute() {

  	
  	List<String> contents = UtilFile.readFile("C:\\Users\\KirbyPC\\workspace_CSCI8710_Kirby\\project-ex-0924-table-kirby\\input_add.csv");
		List<List<String>> tableContents = UtilFile.convertTableContents(contents);

		persons = new ArrayList<Person>();                     
		      persons.add(new Person("Lucas", "Smith", "502-111-1111", "lucas.smith@email.com"));
		      persons.add(new Person("Mia", "Johnson", "502-111-2222", "mia.johnson@email.com"));
          // Load the data sets from a file dynamically. 

   }
   public List<Person> getPersons() {
 		return persons;
 	}
}


/*
PersonModelProvider personInstance = PersonModelProvider.INSTANCE;
AddPersonDialog dialog = new AddPersonDialog(shell);
dialog.open();
if (dialog.getPerson() != null) {
   personInstance.getPersons().add(dialog.getPerson());
   MPart findPart = epartService.findPart(MyTableViewer.ID);
   Object findPartObj = findPart.getObject();

   if (findPartObj instanceof MyTableViewer) {
      MyTableViewer v = (MyTableViewer) findPartObj;
      v.refresh();
   }
}
*/
